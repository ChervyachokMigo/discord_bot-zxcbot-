
import { useContext, useEffect } from 'react'
import { PostContentContext, isAuthedContext } from './Contexts';
import parse from 'html-react-parser';

export default function PostContent (props) {

    const { content } = useContext(PostContentContext);
    const { is_authed } = useContext(isAuthedContext);

    useEffect( () => {

    }, [content, is_authed])

    if (is_authed) {
        return (
            <div className={content ? 'post_content' : 'post_content_hidden'}>{parse(content)}</div>
        )
    } else {
        return (<div className='emptyDiv'></div>)
    }

}
