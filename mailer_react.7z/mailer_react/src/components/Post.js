
import { useState, useEffect, useContext, useId } from 'react'
import { PostContentContext, isAuthedContext, TokenContext, SelectedPostContext } from './Contexts';

export default function Post (props) {
    const id = useId(); 

    const [isOpened, setOpened] = useState(false);

    const {setContent} = useContext(PostContentContext);
    const {is_authed, setAuth} = useContext(isAuthedContext);
    const {token, setToken} = useContext(TokenContext);
    const {selectedPost, setSelectedPost} = useContext(SelectedPostContext)

    useEffect( () => {
        if (!token){
            console.log('not token');
        }
        if (!is_authed){
            console.log('not is_authed');
        }
        if (!isOpened){
            console.log('not isOpened');
        }
        if (!props.name){
            console.log('not props.name');
        }
        if (!props.addressee){
            console.log('not props.addressee');
        }
        if (token && is_authed && isOpened && props.name && props.addressee){
            fetch('https://api.svdgod.ru/query?action=posts_content&addressee=' + props.addressee +
            '&post=' + props.name + '&token=' + token)
            .then(response => response.json())
            .then(data => {
                if (data.error){
                    console.log(data.error);
                    setAuth(false);
                    setToken('');
                    setContent('');
                    return;
                }
                setContent(data.content);
            })
            .catch(error => console.log(error));
        }
    }, [isOpened, token, is_authed, setAuth, setToken, setContent, props.name, props.addressee])

    const openPost = (e) =>{
        setSelectedPost(id);
    }

    useEffect( ()=> {
        if (id && selectedPost){
            if (id.includes(selectedPost)){
                setOpened( true );
            } else {
                setOpened( false );
            }
        }
    }, [selectedPost, props.name, setSelectedPost, id])

    return (
        <div className={isOpened? 'PostOpen' : 'PostClose'} 
            onClick={ openPost }>
                {props.name}
        </div>)

}
