
import { useState, useEffect, useContext } from 'react'
import Addressee from './Addressee';
import { isAuthedContext } from './Contexts';

export default function Inbox (props){

    const [addressees, setAddressees] = useState([]);

    const {is_authed} = useContext(isAuthedContext);

    useEffect(() => {
        fetch('https://api.svdgod.ru/query?action=inbox')
            .then(response => response.json())
            .then(data => {
                setAddressees(data.inbox);
            })
            .catch(error => console.log(error));
    }, []);

    if (is_authed){
        if ( addressees && addressees.length > 0 ){
            return (<div>
                <h2>Inbox</h2>
                <div>
                    { addressees.map( (name) => <Addressee name={name} />) }
                </div>
            </div>)
        } else {
            return (<div>&lt; Пусто &gt;</div>);
        }
    } else {
        return (
            <div>
                (debug) posts loading...
            </div>
        )
    }

}
