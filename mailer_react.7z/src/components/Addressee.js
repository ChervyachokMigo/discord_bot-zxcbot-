
import { useState, useEffect } from 'react'
import Post from './Post';
import { PostContextProvider } from './Contexts';

export default function Addressee (props) {

    const [isOpened, toggleAddressee] = useState(false);
    const [posts, setPosts] = useState();

    const openAddressee = () =>{
        const notIsOpened = !isOpened;
        toggleAddressee( notIsOpened );
        if (notIsOpened && props.name){
            fetch('https://api.svdgod.ru/query?action=posts&addressee=' + props.name)
            .then(response => response.json())
            .then(data => {
                setPosts(data.posts);
            })
            .catch(error => console.log(error));
        }
    }

    return (<div>
        <div className={isOpened?'AddresseeOpen':'AddresseeClose'} onClick={ () => openAddressee() }>{props.name}</div>
        { isOpened && 
            ( posts ? posts.length > 0 ? 
                posts.map( postName => <Post addressee={props.name} name={postName} />) : 
            <div>&lt; Пусто &gt;</div> :
        <div></div> )}
    </div>)

}
