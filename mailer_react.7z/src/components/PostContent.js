
import { useState, useEffect, useContext } from 'react'
import { PostContentContext } from './Contexts';

export default function PostContent (props) {

    const { content } = useContext(PostContentContext);
    console.log(content)
    return (<div> 
        <pre>{content}</pre>
    </div>)

}
