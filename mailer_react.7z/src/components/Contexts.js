
import { createContext,  useState } from 'react'

const isAuthedContext = createContext( null );
const PostContentContext = createContext( null );

function AuthedProvider({children}) {
  const [is_authed, setAuth] = useState(false);
  const value = {is_authed, setAuth};
  return (<isAuthedContext.Provider value={value}>{children}</isAuthedContext.Provider>);
}

function PostContextProvider({children}) {
  const [content, setContent] = useState('no content');
  const value = {content, setContent};
  return (<PostContentContext.Provider value={value}>{children}</PostContentContext.Provider>);
}

export {isAuthedContext, PostContentContext, AuthedProvider, PostContextProvider}