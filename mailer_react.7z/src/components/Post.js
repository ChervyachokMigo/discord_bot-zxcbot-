
import { useState, useEffect, useContext } from 'react'
import { PostContentContext } from './Contexts';

export default function Post (props) {
    const [isOpened, togglePost] = useState(false);
    const {setContent} = useContext(PostContentContext);

    const openPost = () =>{
        const notIsOpened = !isOpened;
        togglePost( notIsOpened );
        if (notIsOpened && props.name){
            fetch('https://api.svdgod.ru/query?action=posts_content&addressee=' + props.addressee +
            '&post=' + props.name)
            .then(response => response.json())
            .then(data => {
                setContent(data.content);
            })
            .catch(error => console.log(error));
        }
    }

    return (
        <div className={isOpened?'PostOpen':'PostClose'} 
            onClick={ () => openPost() }>
                {props.name}
        </div>)

}
