
import { useContext, useEffect, useState } from 'react'
import { isAuthedContext } from './Contexts';

export default function Auth (props) {

    const {is_authed, setAuth} = useContext(isAuthedContext);
    const [auth_key, setAuthKey] = useState('');

    const submitKey = () => {
        fetch('https://api.svdgod.ru/query?action=auth_request&auth_key='+auth_key)
        .then(response => response.json())
        .then(data => {
            setAuth(data.is_authed);
            if (data.is_authed === false) {
                fetch('https://api.svdgod.ru/query?action=get_new_key')
                .catch(error => console.log(error));
            }
        })
        .catch(error => console.log(error)) 
    }

    const handleChange = (event) => {
        setAuthKey(event.target.value);
    }

    if (is_authed === false){
        return (<div>
            <label htmlFor="auth_key">Auth</label><input type="text" name="auth_key" value={auth_key}
            required minlength="6" maxlength="8" placeholder="Enter key" onChange={handleChange} />
            <button type="button" onClick={submitKey}>Auth</button>
        </div>)
    }

    if (is_authed === true){
        /*return (
            <div>
                (debug) auth loading...
            </div>
        )
    } else {*/
        return (<div className='emptyDiv'></div>);
    }

}