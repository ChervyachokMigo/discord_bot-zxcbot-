
import {useState, useEffect, useContext } from 'react'
import Auth from './components/Auth'
import Inbox from './components/Inbox'
import PostContent from './components/PostContent'
import { isAuthedContext, PostContextProvider } from './components/Contexts'

export default function App () {

    const {setAuth} = useContext(isAuthedContext);

    useEffect(() => {
        fetch('https://api.svdgod.ru/query?action=is_authed')
            .then(response => response.json())
            .then(data => {
                setAuth(data.is_authed);
                console.log('is_authed data', data)
                if (data.is_authed === false){
                    fetch('https://api.svdgod.ru/query?action=get_new_key')
                    .catch(error => console.log(error));
                } else {
                    console.log('set token')
                }
            })
            .catch(error => console.log(error));
    }, []);

    return (<div>
        <header>Welcome to Mail</header>
        <main>
            <Auth />
            <PostContextProvider>
                <Inbox />
                <PostContent />
            </PostContextProvider>
            
        </main>
    </div>)
    
}
